package com.crud;

public class Main {

    public static void main(String[] args) {
        menuTampilan tampil = new menuTampilan();
        tampil.tampildata();
    }
}
