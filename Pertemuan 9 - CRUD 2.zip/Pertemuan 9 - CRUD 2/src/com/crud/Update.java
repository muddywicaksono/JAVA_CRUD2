package com.crud;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;

public class Update extends JFrame {
    JLabel ljudul;
    JButton edit,kembali;
    Statement statement;
    ResultSet resultSet;
    String[][] data = new String[500][4];
    String[] kolom = {"Nim","Nama","Alamat"};
    JTable tabel;
    JScrollPane scrollPane;

    public Update() throws ClassNotFoundException, SQLException{
        ljudul = new JLabel ("Seluruh Data Mahasiswa");
        edit = new JButton ("Edit");
        kembali = new JButton ("Kembali");
        tabel = new JTable(data,kolom);
        scrollPane = new JScrollPane(tabel);

        setTitle("EDIT DATA MAHASISWA");
        setSize (700,600);
        ljudul.setHorizontalAlignment(SwingConstants.CENTER);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

        setLayout(null);
        add(ljudul);
        add(edit);
        add(kembali);

        ljudul.setBounds(150, 50, 250, 30);
        edit.setBounds(150, 90, 100, 20);
        kembali.setBounds(270, 90, 100, 20);

        setLayout(new FlowLayout());
        add(scrollPane);

        ConnectionDB connect = new ConnectionDB();
        statement = connect.getKoneksi().createStatement();
        String sql = "SELECT *FROM data_mhs";
        resultSet = statement.executeQuery(sql);
        int p = 0;
        while (resultSet.next()){
            data[p][0] = resultSet.getString("nim");
            data[p][1] = resultSet.getString("nama");
            data[p][2] = resultSet.getString("alamat");
            p++;
        }
        statement.close();

        edit.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                new updateProcces();
            }
        });

        kembali.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                menuTampilan tampil = new menuTampilan();
                tampil.tampildata();
            }
        });

    }
}
