package com.crud;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.*;

public class formMhs extends JFrame {
    JLabel lnama,lnim,lalamat;
    JTextField txnama,txnim,txalamat;
    JButton save,back;
    Statement statement;

        public formMhs (){

            setTitle("From Pengisian Mahasiswa");

            lnim = new JLabel("NIM");
            lnama = new JLabel("Nama");
            lalamat = new JLabel("Alamat");

            txnim = new JTextField("");
            txnama = new JTextField("");
            txalamat = new JTextField("");

            save = new JButton("Simpan");
            back = new JButton("Kembali");


            setLayout(null);
            add(lnim);
            add(lnama);
            add(lalamat);
            add(txnim);
            add(txnama);
            add(txalamat);
            add(save);
            add(back);


            lnim.setBounds(75, 50, 30, 20);
            lnama.setBounds(75, 75, 50, 20);
            lalamat.setBounds(75, 125, 50, 20);
            txnim.setBounds(150, 50, 150, 20);
            txnama.setBounds(150, 75, 150, 20);
            txalamat.setBounds(150, 125, 150, 100);
            save.setBounds(75, 230, 75, 20);
            back.setBounds(155, 230, 75, 20);

            setSize(450,400); //untuk luas jendela

            setVisible(true);
            setDefaultCloseOperation(EXIT_ON_CLOSE);

        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int a1 =  Integer.parseInt(txnim.getText());
                    String a2 = txnama.getText();
                    String a3 = txalamat.getText();

                    ConnectionDB connect = new ConnectionDB();
                    try {
                        statement = connect.getKoneksi().createStatement();
                        String sql = "INSERT INTO data_mhs VALUES ('"
                                + a2 + "','" + a1 + "','" + a3 + "')";
                        statement.executeUpdate(sql);
                        JOptionPane.showMessageDialog(rootPane, "Data Tersimpan");
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(formMhs.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (SQLException ex) {
                        Logger.getLogger(formMhs.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(rootPane,"TIPE DATA SALAH");
                } catch (Error ext){
                    JOptionPane.showMessageDialog(rootPane,"SALAH");
                }
            }
        });

        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                setVisible(false);
                menuTampilan tampil = new menuTampilan();
                tampil.tampildata();
            }
        });
    }
}
